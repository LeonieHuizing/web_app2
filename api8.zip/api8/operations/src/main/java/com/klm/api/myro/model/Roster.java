package com.klm.api.myro.model;

public class Roster {

	private int id;
	private String name;
	private String title;
	private int startjaar;
	private int startmaand;
	private int startdag;
	private int startuur;
	private int startminuten;
	private int eindjaar;
	private int eindmaand;
	private int einddag;
	private int einduur;
	private int eindminuten;
	
	
	public Roster(){
		
	}
	
	public Roster(int id, String name, String title, int startjaar, int startmaand, int startdag, int startuur, int startminuten, int eindjaar, int eindmaand, int einddag, int einduur, int eindminuten) {
		this.id = id;
		this.setName(name);
		this.setStartjaar(startjaar);
		this.setStartmaand(startmaand);
		this.setStartdag(startdag);
		this.setStartuur(startuur);
		this.setStartminuten(startminuten);
		this.setEindjaar(eindjaar);
		this.setEindmaand(eindmaand);
		this.setEinddag(einddag);
		this.setEinduur(einduur);
		this.setEindminuten(eindminuten);
		this.setTitle(title);
	}
	
	//GETTER AND SETTERS
	public int getId(){
		return id;
	}
	
	public void setId(int id){
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	} 
	
	public int getStartjaar() {
		return startjaar;
	}

	public void setStartjaar(int startjaar) {
		this.startjaar = startjaar;
	}

	public int getStartmaand() {
		return startmaand;
	}

	public void setStartmaand(int startmaand) {
		this.startmaand = startmaand;
	}

	public int getStartdag() {
		return startdag;
	}

	public void setStartdag(int startdag) {
		this.startdag = startdag;
	}

	public int getStartuur() {
		return startuur;
	}

	public void setStartuur(int startuur) {
		this.startuur = startuur;
	}

	public int getStartminuten() {
		return startminuten;
	}

	public void setStartminuten(int startminuten) {
		this.startminuten = startminuten;
	}

	public int getEindjaar() {
		return eindjaar;
	}

	public void setEindjaar(int eindjaar) {
		this.eindjaar = eindjaar;
	}

	public int getEindmaand() {
		return eindmaand;
	}

	public void setEindmaand(int eindmaand) {
		this.eindmaand = eindmaand;
	}

	public int getEinddag() {
		return einddag;
	}

	public void setEinddag(int einddag) {
		this.einddag = einddag;
	}

	public int getEinduur() {
		return einduur;
	}

	public void setEinduur(int einduur) {
		this.einduur = einduur;
	}

	public int getEindminuten() {
		return eindminuten;
	}

	public void setEindminuten(int eindminuten) {
		this.eindminuten = eindminuten;
	}


}
