package com.klm.api.myro.database;

import java.util.HashMap;
import java.util.Map;

import com.klm.api.myro.model.Roster;

public class Database {

	//This class represent a database. 
	//connection to our CSV file will be here?
	//This maps the id to the roster
	private static Map<Long, Roster> rosters = new HashMap<>();
	
	public static Map<Long, Roster> getRosters(){
		return rosters;
	}
}
