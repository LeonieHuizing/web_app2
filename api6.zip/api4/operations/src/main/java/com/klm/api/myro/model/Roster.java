package com.klm.api.myro.model;

public class Roster {

	private long id;
	private String message;
	private String employeeName;
	
	public Roster(){
		
	}
	
	public Roster(long id, String message, String employeeName) {
		this.id = id;
		this.setMessage(message);
		this.setEmployeeName(employeeName);
	}
	
	//GETTER AND SETTERS
	public long getId(){
		return id;
	}
	
	public void setId(long id){
		this.id = id;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	
	
	

}
